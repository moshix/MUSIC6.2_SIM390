
                           MUSIC/SP Manuals

                              June 1996


                                        (This file updated Oct 9, 2006)


Some MUSIC/SP manuals are available on MUSIC/SP itself (the MAN and
MANX commands), as well as in PDF format downloadable from the Web.
The .pdf files can be viewed using the Adobe Acrobat Reader (version 4
or higher) program.

These manuals correspond to MUSIC/SP 5.1, and most of them are from
1996.  Some of the information they contain is slightly out of date
for later versions of MUSIC/SP such as 6.x, but most of the material
still applies.  Please note that not all of the features and products
described in the manuals are available on all MUSIC systems.  In
particular, many of the components are not in the 6.x Demo System.

These manuals are Copyright McGill University.


***************************** MANUAL FILES ****************************

Some of the manuals have been divided into parts (as indicated
below).  The beginning of each manual includes the Title pages
and Prefix.  The end of each manual includes the Glossary (if
any), Appendixes, Index, Table of Contents, and List of Figures.

NOTE:  If you print these files, it is recommended that they
       be printed duplex (2-sided).


Manual Name / Description       Contents         File         Pages
-------------------------       --------         ----         -----

Administrator's Guide           All              ag.pdf        1 - 156

Administrator's Ref.
  Part I-II Plan,Oper           Begin - Chp 5    ar_p1.pdf     1 -  40
  Part III Customizing          Chp 6 - Chp 9    ar_p2.pdf    41 - 140
  Part III Customizing          Chp 10 - Chp 16  ar_p3.pdf   141 - 238
  Part IV Utilities             Chp 17           ar_p4.pdf   239 - 358
  Part V Internals              Chp 18 - Chp 23  ar_p5.pdf   359 - 498
  Appendixes, TOC               Appndx - end     ar_p6.pdf   499 - end

User's Reference Guide
  Intro,workstns,Batch,files    Begin - Chp 4    ur_p1.pdf     1 -  86
  Commands, ctl statements      Chp 5 - Chp 6    ur_p2.pdf    87 - 190
  Editor                        Chp 7            ur_p3.pdf   191 - 312
  Processors                    Chp 8            ur_p4.pdf   313 - 458
  Subroutines                   Chp 9            ur_p5.pdf   459 - 548
  Utilities,Appndx,Indx,TOC     Chp 10 - end     ur_p6.pdf   549 - end

Guide for New Users             All              gnu.pdf       1 - 164

Mail & Conferencing             All              mc.pdf        1 - 142

Office Applications Guide
  Intro,menus,editor,mail       Begin - Chp 4    oa_p1.pdf     1 - 102
  Script,TODO,utilities         Chp 5 - end      oa_p3.pdf   103 - end

Campus-Wide Info. Systems       All              cwis.pdf      1 - 98

Teacher's Guide                 All              tg.pdf        1 - 156

Internet Guide                  All              ig.pdf        1 - 92

PCWS Guide, 1994 edition        All              pcws.pdf      1 - 72

