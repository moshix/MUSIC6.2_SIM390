
Sim390 mainframe emulator, version 1.7, Feb. 25, 2008

(c) Copyright Dave Edwards, 2001 - 2008. All rights reserved.


Conditions of Use:

The Sim390 software is provided on an "as-is" basis, and is intended
only for demonstration and evaluation purposes.  Use it at your own
risk.  The author is not responsible for any damages or losses that
may occur from your use of this software, and no support or warranty
is provided.  This software must not be used, sold, or distributed for
profit, without the written permission of the author.  It is provided
only for personal use by individuals.  Use in a production or
commercial or institutional environment is prohibited, unless specific
written permission is obtained from the author.


Installation Instructions:

Sim390 is distributed as a .zip file, which contains the latest
versions of the Sim390 executable (.exe) file, the HTML help file, and
other related files, such as a sample configuration file.  For
example, file sim390_17.exe in the .zip file is version 1.7 of
sim390.exe.

After downloading the .zip file, check its MD5 or SHA1 digest with the
digest listed on the Sim390 home page. This verifies that you have an
authentic, uncorrupted copy.

Use WinZip (or an equivalent utility) to unzip the files to a
temporary directory on your Windows system, create a new directory for
Sim390, for example c:\sim390 or c:\sim390dm, and copy the .exe and
.htm files to it, renaming them to sim390.exe and sim390_help.htm.  If
you are updating a previous version of Sim390, just replace your
existing sim390.exe and sim390_help.htm files.

To start Sim390, enter the following command in a Command Prompt window:

     sim390 xxx

where xxx is the name of a configuration file.

To actually IPL (Initial Program Load) and run a mainframe operating
system under Sim390, you will need to prepare a configuration file and
obtain the volume file(s) for the operating system.  Typically, Sim390
is used to run the MUSIC/SP Demo system, which is distributed
separately.

For more details, see the HTML help file.

